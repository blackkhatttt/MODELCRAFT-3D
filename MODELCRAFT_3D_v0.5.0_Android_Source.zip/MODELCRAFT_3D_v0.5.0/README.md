# MODELCRAFT 3D v0.5.0 — Android Edition

This release preserves the v0.4.0 editor and prepares it as a Capacitor Android application. The editor remains offline-first and does not load a remote 3D engine.

## Included
- Original Canvas 3D editor, Object Mode and Edit Mode.
- Primitive creation and CustomMesh recipe import.
- OBJ export and MODELCRAFT JSON recipe export/import.
- Local scene autosave and restore using browser storage on the device.
- Capacitor 7 project configuration for Android.
- Mobile safe-area and viewport adjustments.

## Run as a web app
Open `www/index.html` in a modern browser. For reliable local autosave, use a local web server or the Android app rather than a browser's temporary file preview.

## Build the Android app
Requirements: Node.js 20+, Android Studio, Android SDK Platform Tools, and a compatible JDK (17 recommended for the generated Capacitor 7 Android project).

1. Install Node dependencies:
   ```bash
   npm install
   ```
2. Generate the native Android project (only needed once):
   ```bash
   npx cap add android
   ```
3. Sync the web editor into Android:
   ```bash
   npx cap sync android
   ```
4. Open the Android project:
   ```bash
   npx cap open android
   ```
5. In Android Studio, wait for Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Debug APK output is normally:
`android/app/build/outputs/apk/debug/app-debug.apk`

After changing files in `www/`, run `npx cap sync android` again before building.

## Notes
- This ZIP is the complete web source and Capacitor setup. It does **not** contain a compiled APK or a generated `android/` Gradle project because Android SDK/Gradle tooling is not included in this build environment.
- No custom app icon was supplied for this project, so the native project will initially use Capacitor's default icon until a project icon is added.
- AI Studio remains a manual JSON bridge: it does not call an AI service directly.
- Local autosave stores the current scene on the device. Use **Export recipe** to create a portable backup.
